import React from "react";
import banner from '../../assets/banner-superior.jpg'


const AppBanner = () => {
  return (
    <div>
        <img src={banner} style={{width:'100%'}}/>
    </div>
  );
};

export default AppBanner;