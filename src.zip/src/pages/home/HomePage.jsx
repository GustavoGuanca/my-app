import React from 'react';
import AuthenticationHelper from '../../shared/helpers/AppAuthenticationHelper';
import AppCarrusel from '../layout/components/content/AppCarrousell'

const HomePage = () => (
  <>
    <AppCarrusel/>
  </>
);

export default HomePage;
